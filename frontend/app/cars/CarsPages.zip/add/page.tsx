import CarForm from "../../CarForm";

export default function AddCarPage() {
  return <CarForm />;
}
